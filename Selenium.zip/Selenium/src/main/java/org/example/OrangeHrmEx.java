package org.example;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.File;
import java.io.IOException;
import java.time.Duration;

public class OrangeHrmEx {

    public static void main(String[] args) throws IOException {
        long timeStart = System.currentTimeMillis();
        ChromeOptions options = new ChromeOptions();
        options.addArguments("window-size=1400,800");
        options.addArguments("headless");
        ChromeDriver driver = new ChromeDriver(options);
        //define the url
        driver.get("https://opensource-demo.orangehrmlive.com/");

        //maximize the window
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        //get the title of the webpage
        String pageTitle = driver.getTitle();
        System.out.println("The title of this page is ===> " +pageTitle);
        driver.findElement(By.id("txtUsername")).sendKeys("Admin");
        driver.findElement(By.id("txtPassword")).sendKeys("admin123");
        //enter the locator of login button and click
        driver.findElement(By.id("btnLogin")).click();

//        wait for the page to load
        driver.manage().timeouts().pageLoadTimeout(Duration.ofSeconds(10));
        WebDriverWait wait = new WebDriverWait (driver,Duration.ofSeconds(15));
        WebElement element = wait.until(ExpectedConditions.elementToBeClickable(By.id("menu_admin_viewAdminModule")));
        element.click();

        driver.findElement(By.xpath("//input[@id = 'searchSystemUser_userName']")).clear();
        driver.findElement(By.xpath("//input[@id = 'searchSystemUser_userName']")).sendKeys("Admin");

       Select selectRole = new Select(driver.findElement(By.id("searchSystemUser_userType")));
        selectRole.selectByVisibleText("All");
        driver.findElement(By.id("searchSystemUser_employeeName_empName")).clear();
//        driver.findElement(By.id("searchSystemUser_employeeName_empName")).sendKeys("Test 1");

        Select selectStatus = new Select (driver.findElement(By.id("searchSystemUser_status")));
        selectStatus.selectByVisibleText("Enabled");
        driver.findElement(By.id("searchBtn")).click();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

        TakesScreenshot ts1 = (TakesScreenshot)driver;
        File file1 = ts1.getScreenshotAs(OutputType.FILE);

        try {
            FileUtils.copyFile(file1, new File("SearchUser.png"));
        } catch (IOException e) {
            e.printStackTrace();
        }
        long totalTime = System.currentTimeMillis() - timeStart;
        System.out.println("Total Time is : "+totalTime);
        driver.close();
        driver.quit();

    }
}
