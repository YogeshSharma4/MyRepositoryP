package org.example;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.File;
import java.io.IOException;
import java.time.Duration;

public class GFGEx {
    public static void main(String[] args) {
        long timeStart = System.currentTimeMillis();
        ChromeOptions options = new ChromeOptions();
        options.addArguments("window-size=1400,800");
        options.addArguments("headless");
        WebDriver driver = new ChromeDriver(options);
        driver.get("https://www.geeksforgeeks.org/");
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        driver.findElement(By.linkText("Sign In")).click();
        WebDriverWait wait = new WebDriverWait (driver,Duration.ofSeconds(5));
        WebElement luser = wait.until(ExpectedConditions.elementToBeClickable(By.id("luser")));
        luser.sendKeys("sharmayogesh229@gmail.com");
        driver.findElement(By.id("password")).sendKeys("geeksforgeeks");
        driver.findElement(By.xpath("//*[@id=\"Login\"]/button")).click();
        WebElement profile=wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//*[@id=\"userProfileId\"]/div/img")));
        profile.click();
        TakesScreenshot ts1 = (TakesScreenshot)driver;
        File file1 = ts1.getScreenshotAs(OutputType.FILE);
        try {
            FileUtils.copyFile(file1, new File("GfG.png"));
        } catch (IOException e) {
            e.printStackTrace();
        }
        long totalTime = System.currentTimeMillis() - timeStart;
        System.out.println("Total Time is : "+totalTime);
    }
}
